from tkinter import*
import tkinter.font as tkFont
from tkinter import ttk



ventana = Tk()
fontStyle = tkFont.Font(family="Helvetica", size=20)

func1_1=PhotoImage(file="funcion11.gif")
func1_2=PhotoImage(file="funcion12.gif")
func2_1=PhotoImage(file="funcion21.gif")
func2_2=PhotoImage(file="funcion22.gif")
func3_1=PhotoImage(file="funcion31.gif")
func3_2=PhotoImage(file="funcion32.gif")
func3_3=PhotoImage(file="funcion33.gif")
func4_1=PhotoImage(file="funcion41.gif")
func4_2=PhotoImage(file="funcion42.gif")
func4_3=PhotoImage(file="funcion43.gif")

ventana.title("Método Newton-Raphson")
ventana.geometry("500x600+300+200")

o1= Label(ventana,text="Opción 1",font=fontStyle).pack()

f1 = Label(ventana,image=func1_1).pack()
f11= Label(ventana,image=func1_2).pack()

o2= Label(ventana,text="Opción 2",font=fontStyle).pack()
f21= Label(ventana,image=func2_1).pack()
f22= Label(ventana,image=func2_2).pack()

o3= Label(ventana,text="Opción 3",font=fontStyle).pack()
f31= Label(ventana,image=func3_1).pack()
f32= Label(ventana,image=func3_2).pack()
f33= Label(ventana,image=func3_3).pack()

o4= Label(ventana,text="Opción 4",font=fontStyle).pack()
f41= Label(ventana,image=func4_1).pack()
f42= Label(ventana,image=func4_2).pack()
f43= Label(ventana,image=func4_3).pack()

var = IntVar()
def sel():
   opcion = "Has elegido la opción " + str(var.get())
   label.config(text = opcion)
s=Label(ventana,text="    ")
R1 = Radiobutton(ventana, text="Opción 1", variable=var, value=1,command=sel).pack()
R2 = Radiobutton(ventana, text="Opción 2", variable=var, value=2,command=sel).pack()
R3 = Radiobutton(ventana, text="Opción 3", variable=var, value=3,command=sel).pack()
R4 = Radiobutton(ventana, text="Opción 4", variable=var, value=4,command=sel).pack()

label=Label(ventana)
label.pack()

def ventanaA():
	ventana_A = Tk()
	ventana_A.title("Valores Iniciales")
	ventana_A.geometry("400x280+600+200")
	l0=Label(ventana_A,text="*INGRESA LOS VALORES CORRESPONDIENTES*").pack()
	l1=Label(ventana_A,text="Valor inicial para X").pack()
	valorInicialX= ttk.Entry(ventana_A)
	valorInicialX.pack()
	l2=Label(ventana_A,text="Valor inicial para Y").pack()
	valorInicialY= ttk.Entry(ventana_A)
	valorInicialY.pack()
	l3=Label(ventana_A,text="Número de Iteraciones").pack()
	numeroIteraciones= ttk.Entry(ventana_A)
	numeroIteraciones.pack()
	l4=Label(ventana_A,text="Tolerancia de error").pack()
	tolerancia= ttk.Entry(ventana_A)
	tolerancia.pack()
	calcular = Button(ventana_A, text="Calcular")
	calcular.place(x=170,y=240)
	ventana.iconify()
	ventana_A.mainloop()

def ventanaB():
	ventana_B = Tk()
	ventana_B.title("Valores Iniciales")
	ventana_B.geometry("400x320+600+200")
	l0=Label(ventana_B,text="*INGRESA LOS VALORES CORRESPONDIENTES*").pack()
	l1=Label(ventana_B,text="Valor inicial para X").pack()
	valorInicialX= ttk.Entry(ventana_B)
	valorInicialX.pack()
	l2=Label(ventana_B,text="Valor inicial para Y").pack()
	valorInicialY= ttk.Entry(ventana_B)
	valorInicialY.pack()
	l3=Label(ventana_B,text="Valor inicial para Z").pack()
	valorInicialZ= ttk.Entry(ventana_B)
	valorInicialZ.pack()
	l4=Label(ventana_B,text="Número de Iteraciones").pack()
	numeroIteraciones= ttk.Entry(ventana_B)
	numeroIteraciones.pack()
	l5=Label(ventana_B,text="Tolerancia de error").pack()
	tolerancia= ttk.Entry(ventana_B)
	tolerancia.pack()
	calcular = Button(ventana_B, text="Calcular")
	calcular.place(x=170,y=285)
	ventana.iconify()
	ventana_B.mainloop()



def ventana2():
	seleccion=var.get()
	if seleccion ==1:
		ventanaA()
	if seleccion == 2:
		ventanaA()
	if seleccion == 3:
		ventanaB()
	if seleccion == 4:
		ventanaB()	

continuar = Button(ventana, text="Continuar",command=ventana2)
continuar.pack()

ventana.mainloop()
